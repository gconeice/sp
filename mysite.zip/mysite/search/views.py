# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.http import urlquote
import datetime
import time
import re

import os,sys

os.chdir(os.getcwd())

# Create your views here.

def search(request):

    if request.GET.has_key('count'):
        count = request.GET['count']
        key = request.GET['key']

        f = open("in.txt", "w")
        f.write(count)
        f.write('\n')
        f.write(key)
        f.write('\n')
        f.close()
        
        os.system("g++ -o ts -O2 ./search/main.cpp")
        os.system("./ts < in.txt > out.txt")

        f = open("out.txt", "r")
        result = f.read()
        f.close()
        
    else:
        key = ""
        count = ""
        result = ""

    return render(request, "index.html", \
                  {'key': key, \
                   'count': count, \
                   'result': result, \
                   })
