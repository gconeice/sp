#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <vector>
#include <map>
#include <iostream>
#include <string>
#include <fstream>
#include <ctime>

using namespace std;

const int N = 1025; //  所能生成的表大小
const int M = 20000;
struct Pro // 合成过程
{
	int a, b;
}tmp;
vector<Pro> process[N][N];
vector<int> no[N];
map<int, int> target;
bool check[N][N]; // 是否可达
bool pd[M];
int n;
int ord[M]; // 目标
struct Node
{
	int key;
	int val;
	bool operator < (const Node &A) const
		{
			return key > A.key;
		}
}node[N]; // 贪心排序用
vector<Pro> ans;

int Search(int x, int y) // 尝试制备x和y，返回覆盖的数目
{
	vector<int> product;
	product.clear();
	if (x > y) swap(x, y);
	map<int, int> tmp_target = target;
	if (check[x][y] == 0) return 0;
	int res = 0;
	for (int i = 0; i < process[x][y].size(); i++)
	{
		tmp = process[x][y][i];
		int drop = (tmp.a + tmp.b) >> 1;
		product.push_back(drop);
		if (i == process[x][y].size() - 1) 
			product.push_back(drop);
	}
	for (int i = 0; i < product.size(); i++)
		if (product[i])
		{
			int drop = product[i];
			if (tmp_target[drop] > 0)
			{
				res++;
				tmp_target[drop]--;
			}		
		}
	return res;
}

void Get(int x, int y) // 制备x和y
{
	vector<int> product;
	product.clear();
	if (x > y) swap(x, y);
	for (int i = 0; i < process[x][y].size(); i++)
	{
		tmp = process[x][y][i];
		ans.push_back(tmp);
		int drop = (tmp.a + tmp.b) >> 1;
		product.push_back(drop);
		if (i == process[x][y].size() - 1) 
			product.push_back(drop);
	}
	for (int i = 0; i < product.size(); i++)
		if (product[i])
		{
			int drop = product[i];
			if (target[drop] > 0)
			{
				target[drop]--;
				pd[no[drop][0]] = 1;
				no[drop].erase(no[drop].begin());
			}
		}
}

void Go() // 运行
{
	ans.clear();
	target.clear();
	for (int i = 0; i < N; i++) no[i].clear();
	for (int i = 1; i <= n; i++)
	{
		target[ord[i]]++;
		node[i].val = ord[i];
		node[i].key = 1024;
		int tmp_val = ord[i];
		while (!(tmp_val & 1))
		{
			node[i].key >>= 1;
			tmp_val >>= 1;
		}
	}
	sort(node + 1, node + n + 1);
	for (int i = 1; i <= n; i++)
	{
		pd[i] = 0;
		no[node[i].val].push_back(i);
	}
	for (int i = 1; i <= n; i++)
	{
		if (pd[i]) continue;
		int which = node[i].val;
		int with = 0;
		int maxi = Search(0, which);
		for (int j = i + 1; j <= n; j++)
		{
			if (pd[j]) continue;
			int new_max = Search(which, node[j].val);
			if (new_max > maxi)
			{
				with = node[j].val;
				maxi = new_max;
			}
		}
		Get(which, with);
	}
}

void Init() // 加载表格
{
	ifstream fin("result_c.txt");
	string s;
	while (fin >> s)
	{
		int a, b;
		if (fin >> s)
		{
			fin >> a;
			fin >> s;
			b = 0;
			for (int i = 0; i < s.length() - 1; i++) b = b * 10 + s[i] - '0';
			fin >> s;
			if (s[0] != 'U')
			{
				check[a][b] = 1;
				int step = 0;
				fin >> step;
				while (step--)
				{
					int x, y;
					fin >> x >> y;
					tmp.a = x; tmp.b = y;
					process[a][b].push_back(tmp);
				}
			}
		}
	}
}

int main()
{
	Init();
	for(;;)
	{
		scanf(" %d", &n);
		bool zero = 0;
		for (int i = 1; i <= n; i++)
		{
			scanf(" %d", &ord[i]);
			if (ord[i] == 0) zero = 1;
			if (ord[i] > 1024) zero = 1;
		}
		if (zero)
		{
			printf("输入有误\n");
		}
		else
		{
			clock_t start, finish;
			start = clock();
			Go();
			finish = clock();
   			int step = ans.size();
			printf("需要使用%d步</br>\n", step);
			for (int i = 0; i < step; i++) printf("%d %d</br>\n", ans[i].a, ans[i].b);
			printf("算法耗时%.3fms</br>\n", (double)(finish - start) / CLOCKS_PER_SEC * 1000.0);
		}
		int cl = 0;
		if (!cl) break;
		else printf("\n");
	}
	return 0;
}
